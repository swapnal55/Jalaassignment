public class dupvaluearr {
    void printRepeating(int arr[], int size)
    {
        int i, j;
        System.out.println("Repeated Elements are :");
        for (i = 0; i < size-1; i++)
        {
            for (j = i + 1; j < size; j++)
            {
                if (arr[i] == arr[j])
                    System.out.print(arr[i] + " ");
            }
        }
    }
 
    public static void main(String[] args)
    {
        dupvaluearr repeat = new dupvaluearr();
        int arr[] = {1, 2, 3, 5,1,5,9};
        int arr_size = arr.length;
        repeat.printRepeating(arr, arr_size);
    }
}
