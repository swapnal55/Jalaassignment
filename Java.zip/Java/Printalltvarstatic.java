public class Printalltvarstatic {
      //Static integer variable
   static int var1=77; 
   //non-static string variable
   String var2;

   public static void main(String args[])
   {
	Printalltvarstatic ob1 = new Printalltvarstatic();
	Printalltvarstatic ob2 = new Printalltvarstatic();
	
	ob1.var1=88;
	ob1.var2="I'm Object1";
      
	System.out.println("ob1 integer:"+ob1.var1);
	System.out.println("ob1 String:"+ob1.var2);
	
   }
}
