public class indexofarray {
    public static int  findIndex (int[] my_array, int t) {
        if (my_array == null) return -1;
        int len = my_array.length;
        int i = 0;
        while (i < len) {
            if (my_array[i] == t) return i;
            else i=i+1;
        }
        return -1;
    }
    public static void main(String[] args) {
      int[] my_array = {10, 11, 12, 13, 14, 15, 16, 17, 18, 19};
      System.out.println("Index position of 15 is: " + findIndex(my_array, 15));
      System.out.println("Index position of 17 is: " + findIndex(my_array, 17));
       }
}
