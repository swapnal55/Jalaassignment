public class arrcontspecval {
    public static void main(String[] args) {

        int[] num = {1, 2, 3, 4, 5};
        int find = 5;
        boolean temp = false;
    
        for (int n : num) {
          if (n == find) {
            temp = true;
            break;
          }
        }
        
        if(temp)
          System.out.println(find + " is found.");
        else
          System.out.println(find + " is not found.");
      }
}
