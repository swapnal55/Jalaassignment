public class numsmalllarge {
    
   public static void main(String args[]) 
   {
      int a = 20;
      int b = 40;

		if(a < b)	
      		System.out.println("a is smaller "+ a + " and b is larger number "+b);
		else
        	System.out.println("b is smaller "+ b + " and a is larger number "+a);
          
   }
}
