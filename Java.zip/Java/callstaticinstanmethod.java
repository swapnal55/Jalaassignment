public class callstaticinstanmethod {
    static int i = 50;
    static String s = "JalaTecho";
  
    static void display()
    {
       System.out.println("i:"+i);
       System.out.println("ii:"+s);
    }
  
    void fun()
    {
        //Static method called in non-static method
        display();
    }
    
    public static void main(String args[])
    {
        callstaticinstanmethod obj = new callstaticinstanmethod();
      
        obj.fun();
        
        //Static method called in another static method
        display();
     }
}
