import java.io.*;
import java.util.*;
public class FileNotFoundException {
    public static void main(String[] args) {
        try {
         
              File f=new File("game.txt");   
                
             
            PrintWriter p1=new PrintWriter(new FileWriter(f), true);
                
          
            p1.println("Hello world");
              p1.close();
    
            f.setReadOnly();
    
              PrintWriter p2=new PrintWriter(new FileWriter("game.txt"), true);
            p2.println("Hi Jala");
        }
        catch(Exception ex)
     {
            ex.printStackTrace();
        }
      }
}
