class Demo
{
	Demo()
    {
      System.out.println("Constructor with no argument ");
    }
    // constructor with one argument
    Demo(String name)
    {
        System.out.println("Constructor with one argument String : " + name);
    }
 
    // constructor with two arguments
    Demo(String name, int age)
    {
 
        System.out.println("Constructor with two arguments String and Integer : " + name + " "+ age);
 
    }
 
}
public class Testconstr {
    public static void main(String[] args)
    {
      Demo d = new Demo();  
      Demo d1 = new Demo("swara");
	  Demo d2 = new Demo("rohya", 26);
    }
}
