public class Definevar 
{
    public static void main(String args[])
    {
       /*Define variables for different Data Types int, Boolean, char, float, double and print on the  Console*/
        
        char a = 'J';
        int i = 55;
        byte b = 4;
        short s = 56;
        double d = 5.855457531;
        float f = 4.74f;
  
        System.out.println("char: " + a);
        System.out.println("integer: " + i);
        System.out.println("byte: " + b);
        System.out.println("short: " + s);
        System.out.println("float: " + f);
        System.out.println("double: " + d);
    }
    
}
