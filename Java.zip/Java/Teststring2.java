public class Teststring2 {
    public static void main(String args[])
{  
   String s1="Swara";  
   String s2="Radha";  
 
System.out.println(s1.startsWith("Sw"));
System.out.println(s1.endsWith("a"));  
System.out.println(s1.compareTo(s2));  

 }  
}
