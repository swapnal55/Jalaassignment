public class conssample1 {
    int modelYear;
    String modelName;

  private conssample1(int year, String name) {
    modelYear = year;
    modelName = name;
  }

  public static void main(String[] args) {
    conssample1 myCar = new conssample1(1969, "Mustang");
    System.out.println(myCar.modelYear + " " + myCar.modelName);
  }
}
