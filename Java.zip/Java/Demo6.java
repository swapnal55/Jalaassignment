import java.util.*;
public class Demo6 {
    public static void main(String[] argv)
        throws Exception
    {
  
        String s = "Swara Madam!";
  
      
        Scanner scanner = new Scanner(s);
  
  
        System.out.println("" + scanner.nextLine());
  
  
        System.out.println("" + scanner.ioException());
  
       
        scanner.close();
    }
}
