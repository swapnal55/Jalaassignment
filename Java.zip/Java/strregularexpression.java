import java.util.regex.*;  
public class strregularexpression {
    public static void main(String args[])
{  
System.out.println(Pattern.matches("[wara]", "swara"));
System.out.println(Pattern.matches("[swara]", "s"));
System.out.println(Pattern.matches("[war]", "r")); 
}
}
