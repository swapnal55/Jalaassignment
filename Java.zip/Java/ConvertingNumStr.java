public class ConvertingNumStr {
    public static void main(String args[])
{  
int value=05;  
String s1=String.valueOf(value);  
System.out.println(s1+55); 
}
}
