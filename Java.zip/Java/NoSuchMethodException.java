import java.io.*;
  

class NoSuchMethodError {
 
    public void printer(String myString)
    {
        
        System.out.println(myString);
    }
}
  
public class NoSuchMethodException {
     
    public static void main(String[] args)
    {
        
        NoSuchMethodError obj
            = new NoSuchMethodError();
  
     
        obj.printer("Hello World");
    }
}
