public class Callinstancemethods {
    static int i = 50;
    static String s = "JalaTecho";
  
   void display()
    {
       System.out.println("i:"+i);
       System.out.println("ii:"+s);
    }
  
  
    //static method
    public static void main(String args[])
    {
        Callinstancemethods obj = new Callinstancemethods();
  
            obj.display();
     } 
}
