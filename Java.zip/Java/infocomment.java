class Information 
{
	// Write a program for a Single line comment, multi-line and documentation comments
	void display(String name)
    {
    System.out.println("Hello  " +name);
  /*  
This   
is   
multi line   
comment  
*/  
    }
    
  	public static void main(String[] args) 
  	{
       Information obj = new Information();
       obj.display("swapnal");
       
  	}
/** 
    * This is the main method u
    * @param args Unused 
    * call the display () to show the your name
    */       
}