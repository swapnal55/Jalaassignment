public class funPrintName 
{
    // Write a function to print your name and call the function from main method
	void display(String name)
    {
    System.out.println("my name is " +name);
    }
    
  	public static void main(String[] args) 
  	{
        funPrintName obj = new funPrintName();
       obj.display("swapnal");
       
  	}
}
