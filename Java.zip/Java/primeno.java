public class primeno {
    public static void main(String args[]) 
   {
   int a =3;
   if(a%2 == 0)
    System.out.println(a+" is even");
   else
    System.out.println(a+" is odd");
          
   }
    
}
