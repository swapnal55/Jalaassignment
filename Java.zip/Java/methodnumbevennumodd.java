public class methodnumbevennumodd {
    static void CountEvenOdd(int arr[], int arr_size)
    {
        int count_e = 0;
        int count_o = 0;
        for (int i = 0; i < arr_size; i++) 
{
            if ((arr[i] & 1) == 1)
                count_o++;
            else
                count_e++;
        }
 
        System.out.println("Number of even elements = " +count_e+ " evencount Number of odd elements = "
                           + count_o);
    }
 
 
    public static void main(String[] args)
    {
        int arr[] = { 2, 3, 4, 5, 6 };
        int n = arr.length;
           
 
        CountEvenOdd(arr, n);
    }
}
