import java.util.ArrayList;
import java.util.List;
public class ArrayListDemo {
    public static void main(String[] args)
    {
        
        List<String> al = new ArrayList<>();
 
        
        al.add("radha");
        al.add("Mera");
        al.add("pritee");
        al.add("renu");
        al.add("Didi");
        al.add("Radha");
        al.add("Guiree");
        al.add("Dipak");
        al.add("Divid");
        al.add("Ram");
        
        System.out.println("The size of the ArrayList is: " +al.size());
       
        System.out.println(al);
 
  		al.set(4, "Pankya");
        System.out.println(al);
        
        al.remove("Mera");
 
        
        al.remove("Radha");;
 
        
        System.out.println(al);
        
        System.out.println(al.contains("renu") ); 
        
         al.clear();
         
         System.out.println(al);
         
        System.out.println("The size of the ArrayList is: " +al.size());
    } 
}
