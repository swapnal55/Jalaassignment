public class strilen {
    public static void main(String args[])
{  
String s="JALATechonologie";  
System.out.println("string length is: "+s.length());
}
}
