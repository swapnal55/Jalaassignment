public class trimstri {
    public static void main(String args[])
{  
String s1="  hello string   "; 
System.out.println(s1+"jalaTecho");
System.out.println(s1.trim()+"jalaTecho");
}
}
