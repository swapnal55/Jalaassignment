class DisplayOverloading2
{
    public int disp(char c)
    {
        System.out.println(c);
        return 0;

    }
    public void disp(int c)
    {
       System.out.println(c );
    }
}
public class Demomethover1 {
   
    public static void main(String args[])
    {
        DisplayOverloading2 obj = new DisplayOverloading2();
        obj.disp('a');
        obj.disp(5);
    }
}
