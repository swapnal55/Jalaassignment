public class LogicalOperators {
    int a = 10, b = 20, c = 20, d = 0;

  
        // using logical AND to verify
        // two constraints
        void  logicalAND()
        {
        System.out.println("Logical AND perform");
          System.out.println("Varible 1 = " + a);
          System.out.println("Varible 2 = " + b);
          System.out.println("Varible 3 = " + c);
          
        	if ((a < b) && (b == c)) 
        	{
            	d = a + b + c;
            	System.out.println("The sum is: " + d);
        	}
        	else
            	System.out.println("False conditions");
                
                System.out.println();
        }
        
        void logicalOR()
        {
        System.out.println("Logical OR perform");
          System.out.println("Varible 1 = " + a);
          System.out.println("Varible 2 = " + b);
          System.out.println("Varible 3 = " + c);
          
        	if (a > b || c == d)
            	System.out.println("One or both the conditions are true");
        	else
            	System.out.println("Both the conditions are false");
    		System.out.println();
        }
        
        void logicalNot()
        {
        System.out.println("Logical NOT perform");
          System.out.println("Varible 1 = " + a);
          System.out.println("Varible 2 = " + b);
          System.out.println("Varible 3 = " + c);
          
        	System.out.println("!(a < b) = " + !(a < b));
        	System.out.println("!(a > b) = " + !(a > b));
            
            System.out.println();
        }
            
        public static void main(String[] args)
    {    
              
		LogicalOperators obj = new LogicalOperators();
        obj.logicalAND();
        obj.logicalOR();
        obj.logicalNot();
        System.out.println();
   }
    
}
