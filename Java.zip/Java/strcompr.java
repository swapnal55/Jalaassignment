public class strcompr {
    public static void main(String args[])
{  
   String s1="Swara";  
   String s2="Swara";  
   String s3=new String("Swara");  
   String s4="SwaraM";  
   System.out.println(s1.equals(s2));//true  
   System.out.println(s1.equals(s3));//true  
   System.out.println(s1.equals(s4));//false  
 }  
}
