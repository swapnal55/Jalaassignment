public class scopeofvar {
    /**
*Global variables and Local variables based on their scope. The main difference between *Global and local variables is that global variables can be accessed globally in the entire *program, whereas local variables can be accessed only within the function or block in which *they are defined.
*/

int a=5;
void disp()
{
    System.out.println("a is Global varible value" +a);
}

public static void main(String args[])
{
    scopeofvar  obj = new scopeofvar();
  obj.disp();

  int a=10;

    System.out.print("a is local varible value" +a);

}
}
