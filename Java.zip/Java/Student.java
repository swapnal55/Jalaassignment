public class Student {
    int rollno;  
Student(int rollno)
{  
this.rollno=rollno;  

}  

void display()
  {
  System.out.println(rollno);
  }  
}  
class TestThis7{  
public static void main(String args[]){  
Student s1=new Student(111);  

s1.display();  

}
}
