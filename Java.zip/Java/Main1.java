import java.io.BufferedOutputStream;
import java.io.FileOutputStream;

public class Main1 {

  public static void main(String[] args) throws Exception {
    BufferedOutputStream bufferedOutput = new BufferedOutputStream(new FileOutputStream(
        "a.txt"));
    bufferedOutput.write("Line one".getBytes());
    bufferedOutput.write("\n".getBytes());

    bufferedOutput.write(65);
    bufferedOutput.close();
  }
}