public class IncrementDecrement
{
    int number = 5;

    void increment()
    {
    System.out.println("Number is " + number);

    // Increment number.
    number++;
    }
    void decrement()
    {
    // Display the value in number.
    System.out.println("Increment number is " + number);

    // Decrement number.
    number--;

    // Display the value in number.
    System.out.println("Decrement number is " + number);
    }
  public static void main(String[] args)
 {
 IncrementDecrement obj = new IncrementDecrement();
 obj.increment();
 obj.decrement();
 }
    
}
