public class conssample2 {
    int modelYear;
  String modelName;

  protected conssample2(int year, String name) {
    modelYear = year;
    modelName = name;
  }

  public static void main(String[] args) {
    conssample2 myCar = new conssample2(1969, "Mustang");
    System.out.println(myCar.modelYear + " " + myCar.modelName);
  }
}
