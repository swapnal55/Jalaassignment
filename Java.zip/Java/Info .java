 class Info  
{
	// How to create a class, object, method and its signature
	void display()
    {
    System.out.println("Hello Jala Technologies!");
    }
    void display1(int x)
    {
    System.out.println("Number is " +x);
    }
  	public static void main(String[] args) 
  	{
       Info obj = new Info();
       obj.display();
       obj.display1(2);
  	}
    
}
