public class instancemethod {
    public int k;
    public instancemethod(int k) 
	{ this.k = k; }
    public void setK() 
	{ this.k = k; }
     public int getK()
	 { return k; }
 
    public static void main(String[] args)
    {
        instancemethod d = new instancemethod(10);
        System.out.print("Value of k is: " +d.getK());
    }
}
