import java.io.*;
import java.util.*;

  class newsample {
 
    // Method
    void greeting()
    {
        
        System.out.println("hello sir/mam!");
    }
}
 

class ClassNotFoundException{
 
    // Main driver method
    public static void main(String args[])
    {
        
        newsample geeks = new newsample();
 
        // Calling method of above class
        geeks.greeting();
    }
}