public class ValueEqualorNot {
    public static void main(String[] args)
   {
      int num1=3,num2=3;
      
   		if(num1==num2)
        {
			System.out.println("The two numbers are equal");
		}
		else
        {
			System.out.println("The numbers are not equal");
		}
   }
    
}
