public class printlargnum {
    public static void main(String args[]) 
   {
   int a =3,b=8,c=6;
   
   if(a>b&&b>c&&a>c)
   {
    	System.out.println(a+" is Greater");
   }
   else if(b>c && b>a && b>c)
   {
    	System.out.println(b+" is is Greater");
   }
   else
   {
     	System.out.println(c+" is is Greater");
   }
   }
}
