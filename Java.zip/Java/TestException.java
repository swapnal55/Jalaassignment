public class TestException {
    public static void main(String[] args)
    {
        try {
            System.out.println("inside try block");
            
           
            System.out.println(14 / 2);
        }
        
    
        catch (ArithmeticException e) {
            
            System.out.println("Arithmetic Exception");
            
        }
       
        finally {
            
            System.out.println(
                "finally : I execute always.");
            
        }
    }
}
