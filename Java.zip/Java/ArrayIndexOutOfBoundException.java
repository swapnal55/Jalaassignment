public class ArrayIndexOutOfBoundException {
    
    public static void main(String[] args) {  
        String[] ar = {"Swapanal","Swara","MSDhoni","Hero"};   
                                             
                  
                for(int i=0;i<=ar.length;i++) 
        {       
         System.out.println(ar[i]);      
        }  
         }  
}
