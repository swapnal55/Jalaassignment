
    class A
{
    public void disp()
    {
        System.out.println("Super ");
       

    }
    public void disp1()
    {
       System.out.println("class1>>>>" );
    }
    public void sound()
   {
      System.out.println("Animal is making a sound class a");   
   }

}
class B extends A
{
    public void disp2()
    {
        System.out.println("Subclass of a ");
       

    }
    public void disp3()
    {
       System.out.println("class2>>>>" );
    }
    public void sound()
   {
      System.out.println("Animal is making a sound class b");   
   }
}

class C extends B
{
   public void disp4()
    {
        System.out.println("Subclass of b ");
       

    }
    public void disp5()
    {
       System.out.println("class3>>>>" );
    }
   public void sound()
   {
      System.out.println("Animal is making a sound class c ");   
   }
}

public class Sample2inheri 
{
    public static void main(String args[])
    {
         A a = new A();
         a.disp();
         a.disp1();
         a.sound();

         B b = new B();
         b.disp2();
         b.disp3();
         b.sound();

         C c = new C();
         c.disp4();
         c.disp5();
         c.sound();

      
    }
}

