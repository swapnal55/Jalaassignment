public class infotwo {
    
	//  Write a program to print your name
	void display(String name)
    {
    System.out.println("my name is " +name);
    }
    
  	public static void main(String[] args) 
  	{
       infotwo obj = new infotwo();
       obj.display("swapnal");
       
  	}
    
}
