public class CheckEOSwitch {
    public static void main (String args[])
    {
            char c='m'; 
         
             
            switch(c){ 
            case 'm': 
                System.out.println("Gender is male"); 
                break; 
            case 'f': 
                System.out.println("Gender is female"); 
                break; 
            } 
            
    } 
}
