public class strplueoper {
    public static void main(String args[])
    {  
       String s="Swara"+" Mandlik";  
       System.out.println(s);  
     }  
}
