public class strextrstring {
    public static void main(String args[])
    {
 
        String Str = new String("Welcome to JalaTechnologies");
 
       
        System.out.print("The extracted substring  is : ");
        System.out.println(Str.substring(10, 15));
    }
}
