public class staticvarmethod {
    static String var1="static1";
    static String var2="static2";
   
    static void disp()
    {
        System.out.println("Var1 is: "+var1);
        
    }
    static void disp1()
    {
        System.out.println("Var2 is: "+var1);
        
    }
    String var3="Instance1";
    String var4="Instance2";
     void disp3()
        {
        System.out.println("Var3 is: "+var3);
        
          }
          void disp4()
        {
        System.out.println("Var4 is: "+var4);
        
          }
    public static void main(String args[]) 
    {
       
        
        
        disp();
        disp1();
        staticvarmethod o = new staticvarmethod();
        o.disp3();
        o.disp4();
    } 
}
