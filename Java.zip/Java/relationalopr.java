public class relationalopr {
    public static void main(String args[]) {
        int a = 20;
        int b = 40;
  
        System.out.println("a < b = " + (a < b));
        System.out.println("b <= a = " + (b <= a));
        System.out.println("a > b = " + (a > b));
        System.out.println("b >= a = " + (b >= a));
}
}