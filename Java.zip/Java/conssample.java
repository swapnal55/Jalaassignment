public class conssample {
    int modelYear;
    String modelName;
  
    public conssample(int year, String name) {
      modelYear = year;
      modelName = name;
    }
  
    public static void main(String[] args) {
        conssample myCar = new conssample(1969, "Mustang");
      System.out.println(myCar.modelYear + " " + myCar.modelName);
    }
}
