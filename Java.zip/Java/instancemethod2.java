public class instancemethod2 {
    
  static String s = "JalaTecho";
  
  void display()
  {
     System.out.println(s);
     
  }

 
 
    public static void main(String[] args)
    {
 
        
        instancemethod2 d = new instancemethod2();
        d.display();
 
}
}
