abstract class Shape
{  
    abstract void draw();  
    void show()
    {
    System.out.println("non abstract method");
    }
}  

class Rectangle extends Shape
{  
    void draw()
        {
        System.out.println("drawing rectangle");
        }  
        
}  

class Circle1 extends Shape
{  
    void draw()
    {
    System.out.println("drawing circle");
    }  
    void show()
    {
    System.out.println("showing circle");
    }
}  


 class TestAbstranonabstrac
{
    public static void main(String args[])
    {  
        Shape s=new Circle1(); 
        s.show();  
    }  
}
