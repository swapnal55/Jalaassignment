import java.util.Arrays;
public class funremvarr {
    public static void main(String[] args) {
        int[] my_array = {01,10,20,30,40,50,60,70,80,90};
        
        System.out.println("Old Array : "+Arrays.toString(my_array));     
        
       
        int removeIndex = 1;
     
        for(int i = removeIndex; i < my_array.length -1; i++){
             my_array[i] = my_array[i + 1];
           }
    
         System.out.println("After removing the second element: "+Arrays.toString(my_array));
      }
}
