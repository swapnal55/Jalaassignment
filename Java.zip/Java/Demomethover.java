public class Demomethover {
    void multiply(int a, int b)
  {
    System.out.println("Result is"+(a*b)) ;
  }
  void multiply(float a, float b)
  {
    System.out.println("Result is"+(a*b));
  }
  public static void main(String[] args)
  {
    Demomethover obj = new Demomethover();
    obj.multiply(8,5);   
    obj.multiply(4.2f,6.3f);   
  }
}
