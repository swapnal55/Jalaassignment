class ABC{  
    ABC()
    {
    System.out.println("hello JalaTecho");
    }  
    ABC(int x)
    {  
    this();  
    System.out.println(x);  
    }  
    } 
public class TestThis5 {
    public static void main(String args[]){  
        ABC a=new ABC(101);  
        }
}
