import java.lang.reflect.Field;  
public class expExample2 {
    public int num;  
    public static void main(String... args) throws NoSuchFieldException {  
        Class<expExample2> obj = expExample2.class;  
        Field fields = obj.getField("num");  
        System.out.println(fields);  
        Class<?> tp = fields.getType(); 
        System.out.println(tp);  
    }  
}
