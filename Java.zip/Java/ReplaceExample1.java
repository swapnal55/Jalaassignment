public class ReplaceExample1 {
    public static void main(String args[]){  
        String s1="JalaTecho is a very good Course";  
        String replaceString=s1.replace('l','v'); 
        System.out.println(replaceString);  
        }
}
