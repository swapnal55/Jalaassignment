 class AirthmaticOperation {
    public static void main(String args[])
    {
    
    //Write a function for arithmetic operators(+,-,*,/)
      
      int a=15;
      int b=3;
      
     
     		System.out.print("A =" +a+" B="+b);
       
            System.out.println(" is arithmetic operators(+,-,*,/)");
     
            System.out.println("Addition = " +(a+b));

            System.out.println("Subtraction = " +(a-b));
  
        	System.out.println("Multiplication = " +(a*b));

        	System.out.println("Division = " +(a/b));
    	
        
    }
    
}
