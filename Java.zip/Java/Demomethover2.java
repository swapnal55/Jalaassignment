class DisplayOverloading1
{
    public int disp(char c)
    {
        System.out.println(c);
        return 0;

    }
    public void disp(int c)
    {
       System.out.println(c );
    }
}
public class Demomethover2 {
    public static void main(String args[])
    {
        DisplayOverloading1 obj = new DisplayOverloading1();
        obj.disp('a');
        obj.disp(5);
    }
}
