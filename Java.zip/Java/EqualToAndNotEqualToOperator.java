public class EqualToAndNotEqualToOperator {
    public static void main(String[] args)
    {
       int num1=2,num2=3;
       
            if(num1==num2)
         {
             System.out.println("The two numbers are equal");
         }
         else if(num1!=num2)
         {
             System.out.println("The numbers are not equal");
         }
    }
    
}
