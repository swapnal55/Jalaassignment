public class multiconstr {
    
    multiconstr(int i)
    {
        System.out.println(i);
    }

    public static void main(String args[])
    {
        multiconstr b = new multiconstr(10);
        int x = 10;
        while( x > 0)       
        {            
        b = new multiconstr(x--);      
        } 
    }
}
