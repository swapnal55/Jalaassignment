abstract class Test {

    void t1()
    {
        System.out.println("super");

    }

}
  class concret extends Test{

    void t1()
    {
        System.out.println("child");

    }
    void t2()
    {
        System.out.println("child2");

    }

}
public class run {
    public static void main(String[] args) {
        Test t=new concret();

        t.t1();
    }
}
