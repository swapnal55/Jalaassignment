public class strsearching {
    public static void main(String args[])
    {
 
        
        String gfg = new String("Welcome to JalaTechnologies");
 
        System.out.print("Find g first at position : ");
 
        
        System.out.println(gfg.indexOf('s'));
    }
}
