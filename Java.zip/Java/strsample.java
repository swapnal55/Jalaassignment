public class strsample {
    public static void main(String[] args)
    {
        String s = "JalaTecho";
        System.out.println("String s = " + s);     
        String s1 = new String("JalaTecho");
        System.out.println("String s1 = " + s1);
    }
}
