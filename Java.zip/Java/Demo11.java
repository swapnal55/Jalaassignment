import java.util.*;
  

 class Demo11 {
  

    public static void main(String[] args)
    {
  

        HashMap<Integer, String> map = new HashMap<Integer, String>();

       map.put(1, "Edura");
       map.put(2, "Rajiv");
       map.put(3, "sweeta");
       map.put(4, "Welcomes");
       map.put(5, "Yerk");
       map.put(6, "Edin");
       map.put(7, "Rav");
       map.put(8, "swara");
       map.put(9, "White");
       map.put(10, "Yerka");

        System.out.println("Initial Mappings are: " + map);
  

        System.out.println("The cloned map look like this: "+ map.clone());
        System.out.println("Is the map empty? " + map.isEmpty());
        System.out.println("The size of the map is " + map.size());
         map.keySet().iterator().forEachRemaining(System.out::println);
         map.remove(10, "Yerka");
         HashMap<Integer, String> new_map = new HashMap<Integer, String>();
         new_map.putAll(map);
         System.out.println(" copy to all Mappings are: " + new_map);
    }
}